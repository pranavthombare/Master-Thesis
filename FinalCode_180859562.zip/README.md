# Facenet GUI
Python GUI based Face Verification system
## How To Run
```
pip3 install -r requirements.txt
python3 main.py
```
